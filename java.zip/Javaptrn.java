package classProgram;

public class Javaptrn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("   J    A   V     V   A");
System.out.println("   J   A A   V   V   A A");
System.out.println("J  J  AAAAA   V V   AAAAA");
System.out.println("JJJJ A     A   V   A     A");
	}

}
